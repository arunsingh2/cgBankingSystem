package com.cg.banking.exceptions;

public class InvalidAmountException  extends Exception{

}
