package com.cg.banking.exceptions;

public class InvalidPinNumberExcepition  extends Exception{

}
