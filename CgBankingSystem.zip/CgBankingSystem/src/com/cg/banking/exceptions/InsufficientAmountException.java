package com.cg.banking.exceptions;

public class InsufficientAmountException extends Exception {

}
